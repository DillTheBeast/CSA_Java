package Submit1;
public class OddNum {
    public static void main(String[] args) {
        int start = 1;
        for(int i = 1; i < 10; i += 2) {
            System.out.println(i);
        }
    }
}
