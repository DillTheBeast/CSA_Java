package Submit1;

public class Alphabet {
    public static void main(String[] args) {
        for(char c = 'a'; c <= 'z'; c++) {
            System.out.print(c + " ");
        }
        System.out.println();
    }
}
