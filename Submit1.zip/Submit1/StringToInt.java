package Submit1;
import java.util.Scanner;

public class StringToInt {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String str = scan.nextLine();
        int x = Integer.parseInt(str);
        System.out.println(x);
    }
}
